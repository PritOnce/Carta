public class Main {
    public static void main(String[] args) {

        /*Llamamos a la clase Baraja*/
        Baraja b1 = new Baraja();

        /*Llamamos la funcion*/
        b1.crearCarta();
    }
}